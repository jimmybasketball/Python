## 更新日志

- 2018-1-3 ：
  - 发布 release 一键启动 app，详见 [STOP_jump](https://github.com/wangshub/wechat_jump_game/releases)

- 2017-12-30 :
  - 请将安卓手机的 USB 调试模式打开，设置 > 更多设置 > 开发者选项 > USB 调试，如果出现运行脚本后小人不跳的情况，请检查是否有打开 “USB 调试（安全模式）”
  - 根据大家反馈：1080 屏幕距离系数 **1.393**，2K 屏幕为 **1**
  - 添加部分机型配置文件，可直接复制使用

- 2017-12-29 ：
  - 增加更新自动化运行脚本，感谢 GitHub 上的 [@binderclip](https://github.com/binderclip)
